/**
 * 
 */
package demon.service;

/**
 * @author Cacti
 * 
 *	2017年11月27日
 * 
 */
public interface HelloService {
	public String sayHello(String word);
}
